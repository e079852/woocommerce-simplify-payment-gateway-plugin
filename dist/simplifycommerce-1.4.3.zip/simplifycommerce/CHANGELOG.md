# Change Log

## v1.4.3
- Fixing the issue around floating point numbers error (rounding numbers incorrectly on discounted items)
- Direct property access log messages
- Changing downloadable file name to include version number

## v1.4.2
- Adding Qatar to the supported countries list

## v1.4.1
- Using hash_equals in return_handler helps prevent timing attacks.

## v1.4.0
- Display supported card types set by merchant

## v1.3.0
- Save hosted payment for subscription

## v1.2.0
- Adding "Australia" to the supported countries list
- Pass currency code in Hosted Payments args


## v1.1.0
- Fix the card on file not working for subscription payment

## v1.0.0
- First version